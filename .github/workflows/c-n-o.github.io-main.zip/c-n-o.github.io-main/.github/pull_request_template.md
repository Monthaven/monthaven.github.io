## What’s changing
- [ ] UI only  - [ ] Data only  - [ ] Both

## Screenshots / GIF
_(paste)_

## Data sources touched
- [ ] ticker.json  - [ ] navigator/points.json  - [ ] msa/*

## Checks
- [ ] Lighthouse ≥ 90 perf/SEO/accessibility
- [ ] No inline secrets; all external keys in Actions secrets
